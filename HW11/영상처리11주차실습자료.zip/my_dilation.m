function dilation = my_dilation(img, filter)
% Apply dilation of binary image
% img      : binary image
% filter   : filter for dilation
% dilation : result of dilation 

% Apply dilation

end