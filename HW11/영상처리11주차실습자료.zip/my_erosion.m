function erosion = my_erosion(img, filter)
% Apply erosion of binary image
% img     : binary image
% filter  : filter for erosion
% erosion : result of erosion

% Apply erosion

end