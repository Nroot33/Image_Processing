function closing = my_closing(img, filter)
% Calculate closing of binary image
% img     : binary image
% filter  : filter for closing
% closing : result of closing

% Apply closing

end