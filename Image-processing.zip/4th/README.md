## Gaussian filter
> Gaussian 분포를 따르는 필터이다

Low pass filter 중 하나로 실제 데이터들이 Gaussian 분포를 따르는 경우가 많으므로 필터에 gaussian 분포를 이용한 값을 적용하여 필터링 하는 방법이다.
