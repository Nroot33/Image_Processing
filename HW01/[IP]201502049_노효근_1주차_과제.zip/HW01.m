image = imread('1.jpg');
test = my_rgb2gray(image);
imshow(test)