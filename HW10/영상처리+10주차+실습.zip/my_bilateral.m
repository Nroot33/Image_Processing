function filter_img = my_bilateral(img, filter_size, sigma, sigma2)
% Apply bilateral filter
% img        : GrayScale Image
% filter_img : bilateral filtered image 

filter_img = uint8(filter_img/s);

end

